exports.glyphs['c'] =
	unicode: 'c'
	glyphName: 'c'
	characterName: 'LATIN SMALL LETTER C'
	ot:
		advanceWidth: contours[0].nodes[4].expandedTo[0].x + spacingRight
	transforms: Array(
		['skewX',( slant ) / 180 * Math.PI]
	)
	parameters:
		spacingLeft: 50 * spacing + 50 + (0)
		spacingRight: 50 * spacing + 50
	tags: [
		'all',
		'latin',
		'lowercase'
	]
	anchors:
		0:
			x: contours[0].nodes[3].expandedTo[0].x
			y: xHeight + diacriticHeight
		2:
			# to get the same shape of the \e
			e_ref: ( xHeight - ( 100 + ( 85 / 500 ) * xHeight ) + Math.min(
				(37),
				( 37 / 90 ) * thickness
			) + (20) + 250 * crossbar - 250 ) - ( Math.cos( 48 * Math.PI / 180 ) * ( ( ( 113 / 90 ) * thickness ) * 0.75 ) )
		1:
			x: contours[0].nodes[1].expandedTo[0].x
			y: contours[0].nodes[1].expandedTo[0].y + ( 4 / 90 ) * thickness * contrast
	contours:
		0:
			skeleton: true
			closed: false
			nodes:
				0:
					x: contours[0].nodes[4].expandedTo[0].x - 3
					y: Math.min(
						anchors[2].e_ref - 20,
						Math.max(
							overshoot + ( ( ( 93 / 90 ) * thickness ) * Math.cos( (90 - 36) * Math.PI / 180 ) ),
							( overshoot + ( ( ( 93 / 90 ) * thickness ) * Math.cos( (90 - 36) * Math.PI / 180 ) ) ) + (150 * aperture * apertureBottom - 150)
						)
					) + (7)
					dirOut: contours[0].nodes[0].expand.angle + Math.PI / 2
					typeIn: 'smooth'
					expand:
						width: ( 13 / 90 ) * thickness
						angle: Math.min(
							Math.max(
								78 + 50 * aperture * apertureBottom,
								130
							),
							190
						) * Math.PI / 180
						distr: 0.25
				1:
					x: contours[0].nodes[2].expandedTo[0].x + ( contours[0].nodes[0].expandedTo[0].x - contours[0].nodes[2].expandedTo[0].x ) * 0.50
					y: - overshoot
					dirOut: Math.PI
					typeIn: 'smooth'
					expand:
						width: ( 93 / 90 ) * thickness
						angle:( 36 ) / 180 * Math.PI
						distr: 0
				2:
					x: spacingLeft + ( 24 / 90 ) * thickness
					y: ( 240 / 500 ) * xHeight
					dirOut: Math.PI / 2
					typeIn: 'smooth'
					expand:
						width: ( 101 / 90 ) * thickness
						angle:( 20 ) / 180 * Math.PI
						distr: 0.25
				3:
					x: contours[0].nodes[2].expandedTo[1].x + ( contours[0].nodes[4].expandedTo[1].x - contours[0].nodes[2].expandedTo[1].x ) * 0.7
					y: xHeight + overshoot
					dirOut: 0
					typeIn: 'smooth'
					expand:
						width: ( 27 / 90 ) * thickness
						angle:( - 112 ) / 180 * Math.PI
						distr: 0
				4:
					x: Math.min(
						contours[0].nodes[2].expandedTo[0].x + 160 + 200 * width,
						255 + 200 * width
					) - (20)
					x: contours[0].nodes[2].expandedTo[0].x + 160 + 200 * width - (20)
					y: xHeight - 20 - ( 80 / 500 ) * xHeight + (3)
					dirIn:( 95 ) / 180 * Math.PI
					typeOut: 'line'
					expand:
						width: ( 85 / 90 ) * thickness
						angle:( 177 ) / 180 * Math.PI
						distr: 0.75
		1:
			skeleton: false
			closed: true
			nodes:
				0:
					x: contours[0].nodes[4].expandedTo[1].x
					y: contours[0].nodes[4].expandedTo[1].y
					dirOut:( - 85 ) / 180 * Math.PI
				1:
					x: contours[0].nodes[4].expandedTo[1].x + ( contours[0].nodes[4].expandedTo[0].x - contours[0].nodes[4].expandedTo[1].x ) * ( 45 / 85 )
					y: contours[0].nodes[4].expandedTo[0].y - ( contours[0].nodes[4].expandedTo[0].x - contours[1].nodes[1].x )
					type: 'smooth'
					dirOut: 0
				2:
					x: contours[0].nodes[4].expandedTo[0].x
					y: contours[0].nodes[4].expandedTo[0].y
					dirIn:( - 90 ) / 180 * Math.PI
					typeOut: 'line'
