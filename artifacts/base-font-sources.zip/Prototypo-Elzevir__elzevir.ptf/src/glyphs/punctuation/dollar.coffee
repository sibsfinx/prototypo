exports.glyphs['dollar'] =
	unicode: '$'
	glyphName: 'dollar'
	characterName: 'DOLLAR SIGN'
	base: 'S_cap'
	advanceWidth: base.advanceWidth
	tags: [
		'all',
		'latin',
		'punctuation'
	]
	components:
		0:
			base: 'line'
			copy: true
			parentAnchors:
				0:
					x: parentAnchors[0].x - 25 - (15)
					y: capHeight
		1:
			base: 'line'
			copy: true
			parentAnchors:
				0:
					x: parentAnchors[0].x + 25 + (15)
					y: capHeight
