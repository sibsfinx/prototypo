exports.glyphs['A_cap_acute'] =
	unicode: 'Á'
	glyphName: 'Aacute'
	characterName: 'LATIN CAPITAL LETTER A WITH ACUTE'
	base: 'A_cap'
	advanceWidth: base.advanceWidth
	tags: [
		'all',
		'latin',
		'uppercase',
		'diacritic'
	]
	components:
		0:
			base: 'acute'
			copy: true
			parentAnchors:
				0:
					x: parentAnchors[0].x
					y: parentAnchors[0].y
					position: 0.4
