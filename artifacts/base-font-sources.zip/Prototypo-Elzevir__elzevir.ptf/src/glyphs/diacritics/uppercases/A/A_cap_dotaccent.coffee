exports.glyphs['A_cap_dotaccent'] =
	unicode: 'Ȧ'
	glyphName: 'Adotaccent'
	characterName: 'LATIN CAPITAL LETTER A WITH DOT ABOVE'
	base: 'A_cap'
	advanceWidth: base.advanceWidth
	tags: [
		'all',
		'latin',
		'uppercase',
		'diacritic'
	]
	components:
		0:
			base: 'dot_accent'
			copy: true
			parentAnchors:
				0:
					x: parentAnchors[0].x
					y: parentAnchors[0].y
