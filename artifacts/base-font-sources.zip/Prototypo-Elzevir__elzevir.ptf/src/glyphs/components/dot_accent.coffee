exports.glyphs['dot_accent'] =
	global: true
	glyphName: 'dotaccent'
	characterName: 'DOT ACCENT'
	anchors:
		0:
			x: parentAnchors[0].x
			y: parentAnchors[0].y + diacriticHeight
			optical: if typeof parentAnchors[0].optical != 'undefined' then parentAnchors[0].optical else 110
	tags: [
		'component',
		'diacritic'
	]
	contours:
		0:
			skeleton: false
			closed: true
			nodes:
				0:
					x: anchors[0].x
					y: anchors[0].y
					dirOut: Math.PI
					typeIn: 'smooth'
				1:
					x: anchors[0].x - Math.max(
						40,
						Math.min(
							160,
							thickness * ( anchors[0].optical / 90 )
						)
					) / 2
					y: anchors[0].y + Math.max(
						40,
						Math.min(
							160,
							thickness * ( anchors[0].optical / 90 )
						)
					) / 2
					dirOut: Math.PI / 2
					typeIn: 'smooth'
				2:
					x: anchors[0].x
					y: anchors[0].y + Math.max(
						40,
						Math.min(
							160,
							thickness * ( anchors[0].optical / 90 )
						)
					)
					dirOut: 0
					typeIn: 'smooth'
				3:
					x: anchors[0].x + Math.max(
						40,
						Math.min(
							160,
							thickness * ( anchors[0].optical / 90 )
						)
					) / 2
					y: anchors[0].y + Math.max(
						40,
						Math.min(
							160,
							thickness * ( anchors[0].optical / 90 )
						)
					) / 2
					dirOut:( - 90 ) / 180 * Math.PI
					typeIn: 'smooth'
