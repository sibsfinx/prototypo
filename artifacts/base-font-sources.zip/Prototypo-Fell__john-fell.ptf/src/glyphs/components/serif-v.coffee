exports.glyphs['serif-v'] =
	anchors:
		0:
			x: parentAnchors[0].x
			y: parentAnchors[0].y
		1:
			x: parentAnchors[1].x
			y: parentAnchors[1].y
		2:
			anchorLine: parentAnchors[2].anchorLine || 0
			maxWidthTop: if typeof parentAnchors[2].maxWidthTop != 'undefined' then parentAnchors[2].maxWidthTop else false
			maxWidthBottom: if typeof parentAnchors[2].maxWidthBottom != 'undefined' then parentAnchors[2].maxWidthBottom else false
			leftWidth: parentAnchors[2].leftWidth * Math.min( serifWidth / 65, 1 ) || 0
			rightCurve: parentAnchors[2].rightCurve || 1
			midWidthRight: parentAnchors[2].midWidthRight || 1
			midWidthLeft: parentAnchors[2].midWidthLeft || 1
			serifMedianRight: parentAnchors[2].serifMedianRight || 0
			serifMedianLeft: parentAnchors[2].serifMedianLeft || 0
			leftCurve: parentAnchors[2].leftCurve || 1
			rightWidth: parentAnchors[2].rightWidth * Math.min( serifWidth / 65, 1 ) || 0
			# angle: parentAnchors[2].angle || 0
			angleTop: parentAnchors[2].angle || ( parentAnchors[2].angleTop || 0 )
			angleBottom: parentAnchors[2].angle || ( parentAnchors[2].angleBottom || 0)
			directionY: parentAnchors[2].directionY || 1
			directionX: parentAnchors[2].directionX || 1
			anchor_0: parentAnchors[2].anchor_0 || parentAnchors[0].y
			anchor_1: parentAnchors[2].anchor_1 || parentAnchors[1].y
			baseRight: if typeof parentAnchors[2].baseRight != 'undefined' then parentAnchors[2].baseRight else { x: parentAnchors[0].x, y: anchors[2].anchorLine }
			baseLeft: if typeof parentAnchors[2].baseLeft != 'undefined' then parentAnchors[2].baseLeft else { x: parentAnchors[1].x, y: anchors[2].anchorLine }
			max0: parentAnchors[2].max0 || {x: anchors[0].x, y: anchors[0].y}
			max1: parentAnchors[2].max1 || {x: anchors[1].x, y: anchors[1].y}
			left: if typeof parentAnchors[2].left != 'undefined' then parentAnchors[2].left else true
			right: if typeof parentAnchors[2].right != 'undefined' then parentAnchors[2].right else true
			attaque: if typeof parentAnchors[2].attaque != 'undefined' then parentAnchors[2].attaque else false
			vertical: if typeof parentAnchors[2].vertical != 'undefined' then parentAnchors[2].vertical else false
			rightSerifBound: if typeof parentAnchors[2].baseRight != 'undefined' then Utils.onLine( { x: contours[0].nodes[2].x, on: [ anchors[2].baseRight, contours[0].nodes[0] ] } ) else 0;
			leftSerifBound: if typeof parentAnchors[2].baseLeft != 'undefined' then Utils.onLine( { x: contours[0].nodes[8].x, on: [ anchors[2].baseLeft, contours[0].nodes[10] ] } ) else 0;
	tags: [
		'component'
	]
	contours:
		0:
			closed: true
			nodes:
				0:
					# y: Math.max(
					# 	if anchors[2].maxWidthTop != false
					# 	then anchors[2].maxWidthTop - overshoot
					# 	else anchors[0].y
					# , anchors[2].max0.y
					# )
					y: Math.max( anchors[0].y, anchors[2].max0.y )
					x: Math.max( anchors[0].x, anchors[2].max0.x )
					dirOut: anchors[2].angleBottom
					tensionOut: 1.4 * serifRoundness * anchors[2].rightCurve
				1:
					y:
						if anchors[2].right == false
						then anchors[2].baseRight.y
						else
							if parentAnchors[2].baseRight
							then Math.min(Utils.onLine({
								x: contours[0].nodes[1].x
								on: [ anchors[2].baseRight, contours[0].nodes[0] ]
							}) + (serifCurve + serifHeight + anchors[2].rightWidth * anchors[2].rightCurve),
							contours[0].nodes[2].y - Math.sqrt(Math.abs(1 - serifMedian)) * serifWidth - 20 / (serifCurve + serifHeight + anchors[2].rightWidth * anchors[2].rightCurve) * -(contours[0].nodes[2].x - Utils.onLine({
								x: contours[0].nodes[1].x
								on: [ anchors[2].baseRight, contours[0].nodes[0] ]
							}))) else Math.min( contours[0].nodes[2].y - serifWidth / 5 - Math.sqrt(Math.abs(1 - serifMedian)) * serifWidth, anchors[0].y + serifHeight + serifCurve + anchors[2].rightWidth * anchors[2].rightCurve )
					x:
						if anchors[2].right == false
						then anchors[2].baseRight.x
						else anchors[2].anchorLine - serifHeight * anchors[2].directionX
					tensionIn: serifRoundness
					# type: 'smooth'
					dirIn:
						if anchors[2].attaque == true
						then Utils.lineAngle({x: contours[0].nodes[4].x , y: contours[0].nodes[4].y},{x: contours[0].nodes[5].x, y: contours[0].nodes[5].y} )
						else Utils.lineAngle({x: contours[0].nodes[1].x, y: contours[0].nodes[1].y},{x:  contours[0].nodes[2].x, y:  contours[0].nodes[2].y} )
				2:
					y:
						if anchors[2].right == false
						then anchors[2].baseRight.y
						else
							if parentAnchors[2].baseRight
								if anchors[2].baseRight.y > contours[0].nodes[0].y
									Utils.onLine({
										x: contours[0].nodes[2].x
										on: [ anchors[2].baseRight, contours[0].nodes[0] ]
									}) + ( serifWidth + anchors[2].rightWidth * Math.min( 1, serifWidth ) )
								else
									if anchors[2].rightSerifBound > ( anchors[2].baseRight.y + serifWidth + anchors[2].rightWidth * Math.min( 1, serifWidth ) )
										Utils.onLine({
											x: contours[0].nodes[2].x
											on: [ anchors[2].baseRight, contours[0].nodes[0] ]
										})
									else
										if anchors[2].maxWidthTop != false
										then Math.min( anchors[2].maxWidthTop, anchors[2].baseRight.y + serifWidth + anchors[2].rightWidth * Math.min( 1, serifWidth ) )
										else anchors[2].baseRight.y + serifWidth + anchors[2].rightWidth * Math.min( 1, serifWidth )
							else
								if anchors[2].maxWidthTop != false
								then Math.min(
										anchors[2].maxWidthTop,
										anchors[2].anchor_0 + serifWidth + anchors[2].rightWidth * Math.min( 1, serifWidth )
									)
								else anchors[2].anchor_0 + serifWidth + anchors[2].rightWidth * Math.min( 1, serifWidth )
					x:
						if anchors[2].right == false
						then anchors[2].baseRight.x
						else
							if anchors[2].attaque == true
							then contours[0].nodes[4].x - ( serifHeight * serifMedian + anchors[2].serifMedianRight ) + ( (serifWidth + anchors[2].rightWidth) * (anchors[2].anchorLine + ( spurHeight * 50 - 50 ) * anchors[2].directionX) / (anchors[2].baseRight.y + serifWidth * midWidth * anchors[2].midWidthRight + anchors[2].rightWidth) )
							else contours[0].nodes[4].x - ( serifHeight * serifMedian + anchors[2].serifMedianRight ) * anchors[2].directionX
					tensionOut: serifTerminalCurve
					typeOut: 'line'
					typeIn: 'line'
				3:
					y:
						if anchors[2].right == false
						then anchors[2].baseRight.y
						else contours[0].nodes[2].y + ( contours[0].nodes[4].y - contours[0].nodes[2].y ) / 2 + serifTerminal * serifWidth
							# if anchors[2].maxWidthTop != false
							# then Math.min(
							# 		anchors[2].maxWidthTop,
							# 		contours[0].nodes[2].y + ( contours[0].nodes[4].y - contours[0].nodes[2].y ) / 2 + serifTerminal * serifWidth
							# 	)
							# # Math.min( capHeight + overshoot * 2 + serifTerminal * serifWidth, contours[0].nodes[2].y + ( contours[0].nodes[4].y - contours[0].nodes[2].y ) / 2 + serifTerminal * serifWidth )
							# else contours[0].nodes[2].y + ( contours[0].nodes[4].y - contours[0].nodes[2].y ) / 2 + serifTerminal * serifWidth
					x:
						if anchors[2].right == false
						then anchors[2].baseRight.x
						else contours[0].nodes[4].x - (( serifHeight * serifMedian + anchors[2].serifMedianRight ) / 2 ) * anchors[2].directionX
					dirOut: Utils.lineAngle({x: contours[0].nodes[2].x , y: contours[0].nodes[2].y},{x: contours[0].nodes[4].x, y: contours[0].nodes[4].y} )
					typeIn: 'smooth'
					tensionOut: serifTerminalCurve
					tensionIn: serifTerminalCurve
				4:
					y:
						if anchors[2].right == false
						then anchors[2].baseRight.y
						else
							if parentAnchors[2].baseRight
								if anchors[2].baseRight.y < contours[0].nodes[0].y
									if anchors[2].maxWidthTop != false
									then Math.min( anchors[2].maxWidthTop, anchors[2].baseRight.y + serifWidth * midWidth * anchors[2].midWidthRight + anchors[2].rightWidth * Math.min( 1, serifWidth ) )
									else anchors[2].baseRight.y + serifWidth * midWidth * anchors[2].midWidthRight + anchors[2].rightWidth * Math.min( 1, serifWidth )
								else
									if anchors[2].baseRight.y > anchors[2].baseRight.y + serifWidth * midWidth * anchors[2].midWidthRight + anchors[2].rightWidth * Math.min( 1, serifWidth ) - ( Math.abs( Utils.onLine({
										x: contours[0].nodes[2].x
										on: [ anchors[2].baseRight, contours[0].nodes[0] ]
									}) - anchors[2].baseRight.y ) )
										anchors[2].baseRight.y
									else contours[0].nodes[2].y
										# anchors[2].baseRight.y + serifWidth * midWidth * anchors[2].midWidthRight + anchors[2].rightWidth * Math.min( 1, serifWidth ) - ( Math.abs( Utils.onLine({
										# 	x: contours[0].nodes[2].x
										# 	on: [ anchors[2].baseRight, contours[0].nodes[0] ]
										# }) - anchors[2].baseRight.y ) )
							else contours[0].nodes[0].y - ( contours[0].nodes[0].y - contours[0].nodes[2].y ) * midWidth * anchors[2].midWidthRight
					# x:
					# 	if anchors[2].right == false
					# 	then anchors[2].baseRight.x
					# 	else anchors[2].anchorLine
					x: anchors[2].anchorLine
					tensionIn: serifTerminalCurve
					dirIn: Math.PI / 2
					dirOut: 270
				5:
					y:
						if anchors[2].attaque == true
						then anchors[0].y + ( 10 / 85 ) * thickness
						else contours[0].nodes[4].y - ( contours[0].nodes[4].y - contours[0].nodes[6].y ) / 2
					x: anchors[2].anchorLine - ( serifHeight * serifArc ) * anchors[2].directionX
					dirIn:
						if anchors[2].attaque == true
						then Utils.lineAngle({x: contours[0].nodes[4].x , y: contours[0].nodes[4].y},{x: contours[0].nodes[5].x, y: contours[0].nodes[5].y} )
						else Math.PI / 2
					dirOut: 270
				6:
					y:
						if anchors[2].left == false
						then anchors[2].baseLeft.y
						else
							if parentAnchors[2].baseLeft
								if anchors[2].baseLeft.y < contours[0].nodes[10].y
									anchors[2].baseLeft.y - serifWidth * midWidth * anchors[2].midWidthLeft - anchors[2].leftWidth * Math.min( 1, serifWidth )
								else
									if anchors[2].maxWidthBottom == true
									then Math.max( anchors[2].maxWidthBottom,
											if anchors[2].baseLeft.y < anchors[2].baseLeft.y - serifWidth * midWidth * anchors[2].midWidthLeft - anchors[2].leftWidth * Math.min( 1, serifWidth ) + ( Math.abs( Utils.onLine({
												x: contours[0].nodes[8].x
												on: [ anchors[2].baseLeft, contours[0].nodes[10] ]
											}) - anchors[2].baseLeft.y ) )
												anchors[2].baseLeft.y
											else
												anchors[2].baseLeft.y - serifWidth * midWidth * anchors[2].midWidthLeft - anchors[2].leftWidth * Math.min( 1, serifWidth ) + ( Math.abs( Utils.onLine({
													x: contours[0].nodes[8].x
													on: [ anchors[2].baseLeft, contours[0].nodes[10] ]
												}) - anchors[2].baseLeft.y ) )
									)
									else
										if anchors[2].baseLeft.y < anchors[2].baseLeft.y - serifWidth * midWidth * anchors[2].midWidthLeft - anchors[2].leftWidth * Math.min( 1, serifWidth ) + ( Math.abs( Utils.onLine({
											x: contours[0].nodes[8].x
											on: [ anchors[2].baseLeft, contours[0].nodes[10] ]
										}) - anchors[2].baseLeft.y ) )
											anchors[2].baseLeft.y
										else
											anchors[2].baseLeft.y - serifWidth * midWidth * anchors[2].midWidthLeft - anchors[2].leftWidth * Math.min( 1, serifWidth ) + ( Math.abs( Utils.onLine({
												x: contours[0].nodes[8].x
												on: [ anchors[2].baseLeft, contours[0].nodes[10] ]
											}) - anchors[2].baseLeft.y ) )
							else
								if anchors[2].maxWidthTop != false
								then Math.min(
									anchors[2].maxWidthTop,
									contours[0].nodes[10].y - ( contours[0].nodes[10].y - contours[0].nodes[8].y ) * midWidth * anchors[2].midWidthLeft
								)
								else contours[0].nodes[10].y - ( contours[0].nodes[10].y - contours[0].nodes[8].y ) * midWidth * anchors[2].midWidthLeft
					# x:
					# 	if anchors[2].left == false
					# 	then anchors[2].baseLeft.x
					# 	else anchors[2].anchorLine
					x: anchors[2].anchorLine
					tensionOut: serifTerminalCurve
					dirIn: Math.PI / 2
					dirOut: - Math.PI / 2
				7:
					y:
						if anchors[2].left == false
						then anchors[2].baseLeft.y
						else contours[0].nodes[8].y - ( contours[0].nodes[8].y - contours[0].nodes[6].y ) / 2 - serifTerminal * serifWidth
					x:
						if anchors[2].left == false
						then anchors[2].baseLeft.x
						else anchors[2].anchorLine - (( serifHeight * serifMedian + anchors[2].serifMedianLeft ) / 2 ) * anchors[2].directionX
					typeIn: 'smooth'
					dirOut: Utils.lineAngle({x: contours[0].nodes[6].x , y: contours[0].nodes[6].y},{x: contours[0].nodes[8].x, y: contours[0].nodes[8].y} )
					tensionOut: serifTerminalCurve
					tensionIn: serifTerminalCurve
				8:
					y:
						if anchors[2].left == false
						then anchors[2].baseLeft.y
						else
							if parentAnchors[2].baseLeft
								if anchors[2].baseLeft.y > contours[0].nodes[10].y
									Utils.onLine({
										x: contours[0].nodes[8].x
										on: [ anchors[2].baseLeft, contours[0].nodes[10] ]
									}) - ( serifWidth + anchors[2].leftWidth * Math.min( 1, serifWidth ) )
								else
									if anchors[2].leftSerifBound < anchors[2].baseLeft.y - ( serifWidth + anchors[2].leftWidth * Math.min( 1, serifWidth ) )
										Utils.onLine({
											x: contours[0].nodes[8].x
											on: [ anchors[2].baseLeft, contours[0].nodes[10] ]
										})
									else
										if anchors[2].maxWidthBottom == true
										then Math.min( anchors[2].maxWidthBottom, anchors[2].baseLeft.y - ( serifWidth + anchors[2].leftWidth * Math.min( 1, serifWidth ) ) )
										else anchors[2].baseLeft.y - ( serifWidth + anchors[2].leftWidth * Math.min( 1, serifWidth ) )
							else anchors[2].anchor_1 - ( serifWidth + anchors[2].leftWidth * Math.min( 1, serifWidth ) )
					x:
						if anchors[2].left == false
						then anchors[2].baseLeft.x
						else anchors[2].anchorLine - ( serifHeight * serifMedian + anchors[2].serifMedianLeft ) * anchors[2].directionX
					tensionIn: serifTerminalCurve
					typeOut: 'line'
					dirIn: - Math.PI / 2
				9:
					y:
						if anchors[2].left == false
						then anchors[2].baseLeft.y
						else
							if parentAnchors[2].baseLeft
							then Math.max(Utils.onLine({
								x: contours[0].nodes[9].x
								on: [ anchors[2].baseLeft, contours[0].nodes[10] ]
							}) - (serifCurve + serifHeight + anchors[2].leftWidth * anchors[2].leftCurve),
							contours[0].nodes[8].y + Math.sqrt(Math.abs(1 - serifMedian)) * serifWidth + 20 / (serifCurve+serifHeight + anchors[2].leftWidth * anchors[2].leftCurve) * -(contours[0].nodes[8].y - Utils.onLine({
								x: contours[0].nodes[9].x
								on: [ anchors[2].baseLeft, contours[0].nodes[10] ]
							}))) else Math.max( contours[0].nodes[8].y + serifWidth / 5 + Math.sqrt(Math.abs(1 - serifMedian)) * serifWidth, anchors[1].y - serifHeight - serifCurve - anchors[2].leftWidth * anchors[2].leftCurve )
					x:
						if anchors[2].left == false
						then anchors[2].baseLeft.x
						else anchors[2].anchorLine - serifHeight * anchors[2].directionX
					tensionOut: serifRoundness
				10:
					y: Math.max( anchors[1].y, anchors[2].max1.y )
					x: Math.max( anchors[1].x, anchors[2].max1.x )
					dirIn: anchors[2].angleTop
					typeOut: 'line'
					tensionIn: 1.4 * serifRoundness * anchors[2].leftCurve
